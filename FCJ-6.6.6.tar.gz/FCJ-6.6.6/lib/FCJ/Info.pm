package FCJ::Info;

use strict;
use warnings;
our $VERSION="6.6.6";
our $ABSTRACT="💩💩";

require XSLoader;
XSLoader::load('FCJ::Info', $VERSION);



1;
